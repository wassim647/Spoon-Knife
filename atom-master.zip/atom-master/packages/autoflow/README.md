# Autoflow package

Format the current selection to have lines no longer than 80 characters using `cmd-alt-q` on macOS and `ctrl-shift-q` on Windows and Linux. If nothing is selected, the current paragraph will be reflowed.

This package uses the config value of `editor.preferredLineLength` when set to determine desired line length.
