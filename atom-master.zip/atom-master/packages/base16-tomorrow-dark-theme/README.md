# Base16 Tomorrow Dark Syntax theme

Atom theme using the ever popular [Base16 Tomorrow](http://chriskempson.com/projects/base16/) dark colors.

![Base16 Tomorrow light](https://cloud.githubusercontent.com/assets/378023/10118589/f108a568-64b6-11e5-8438-eb34dc9b40a1.png)


## Install

This theme is installed by default with Atom and can be activated by going to the _Themes_ section in the Settings view (`cmd-,`) and selecting it from the _Syntax Themes_ drop-down menu.

A
[light version](../base16-tomorrow-light-theme) of this theme is also available.
